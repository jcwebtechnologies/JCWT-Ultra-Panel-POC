package nginx

import (
	"fmt"
	"os/exec"
	"path/filepath"
	"strings"
	"text/template"
)

const vhostTemplate = `# JCWT Ultra Panel - Managed vhost for {{.Domain}}
# DO NOT EDIT MANUALLY - managed by JCWT Panel

{{- if eq .SSLType "none"}}
server {
    listen [::]:80;
    server_name {{.Domain}}{{if .Aliases}} {{.Aliases}}{{end}};

{{- if eq .SiteType "proxy"}}
    access_log /var/log/nginx/{{.Domain}}-access.log;
    error_log /var/log/nginx/{{.Domain}}-error.log;

    location / {
        proxy_pass {{.ProxyURL}};
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
{{- else}}
    root {{.WebRoot}};
    index index.php index.html index.htm;

    access_log /var/log/nginx/{{.Domain}}-access.log;
    error_log /var/log/nginx/{{.Domain}}-error.log;

    location / {
{{- if eq .SiteType "html"}}
        try_files $uri $uri/ =404;
{{- else}}
        try_files $uri $uri/ /index.php?$query_string;
{{- end}}
    }

{{- if eq .SiteType "php"}}
    location ~ \.php$ {
        fastcgi_pass unix:/run/php/php{{.PHPVersion}}-fpm-{{.User}}.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
{{- end}}

{{- if .BasicAuthEnabled}}
    auth_basic "Restricted Area";
    auth_basic_user_file /etc/nginx/htpasswd/{{.Domain}}.htpasswd;
{{- end}}

    location ~ /\.(ht|git|svn) {
        deny all;
    }
{{- end}}
}
{{- else}}
server {
    listen [::]:80;
    server_name {{.Domain}}{{if .Aliases}} {{.Aliases}}{{end}};
    return 301 https://$host$request_uri;
}

server {
    listen [::]:443 ssl http2;
    server_name {{.Domain}}{{if .Aliases}} {{.Aliases}}{{end}};

    ssl_certificate {{.SSLCertPath}};
    ssl_certificate_key {{.SSLKeyPath}};
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;

{{- if eq .SiteType "proxy"}}
    access_log /var/log/nginx/{{.Domain}}-access.log;
    error_log /var/log/nginx/{{.Domain}}-error.log;

    location / {
        proxy_pass {{.ProxyURL}};
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
{{- else}}
    root {{.WebRoot}};
    index index.php index.html index.htm;

    access_log /var/log/nginx/{{.Domain}}-access.log;
    error_log /var/log/nginx/{{.Domain}}-error.log;

    location / {
{{- if eq .SiteType "html"}}
        try_files $uri $uri/ =404;
{{- else}}
        try_files $uri $uri/ /index.php?$query_string;
{{- end}}
    }

{{- if eq .SiteType "php"}}
    location ~ \.php$ {
        fastcgi_pass unix:/run/php/php{{.PHPVersion}}-fpm-{{.User}}.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
{{- end}}

{{- if .BasicAuthEnabled}}
    auth_basic "Restricted Area";
    auth_basic_user_file /etc/nginx/htpasswd/{{.Domain}}.htpasswd;
{{- end}}

    location ~ /\.(ht|git|svn) {
        deny all;
    }
{{- end}}
}
{{- end}}
`

// VHostData holds template data for nginx vhost generation
type VHostData struct {
	Domain           string
	Aliases          string
	User             string
	SiteType         string
	PHPVersion       string
	ProxyURL         string
	WebRoot          string
	SSLType          string
	SSLCertPath      string
	SSLKeyPath       string
	BasicAuthEnabled bool
}

// GenerateConfig generates an nginx vhost config
func GenerateConfig(data VHostData) (string, error) {
	tmpl, err := template.New("vhost").Parse(vhostTemplate)
	if err != nil {
		return "", fmt.Errorf("parse template: %w", err)
	}

	var buf strings.Builder
	if err := tmpl.Execute(&buf, data); err != nil {
		return "", fmt.Errorf("execute template: %w", err)
	}

	return buf.String(), nil
}

// WriteVHost writes the vhost config file and creates symlink
func WriteVHost(sitesAvailable, sitesEnabled, domain string, data VHostData) error {
	config, err := GenerateConfig(data)
	if err != nil {
		return err
	}

	confPath := filepath.Join(sitesAvailable, domain+".conf")

	// Write via sudo tee since panel user can't write to /etc/nginx/
	cmd := exec.Command("sudo", "tee", confPath)
	cmd.Stdin = strings.NewReader(config)
	cmd.Stdout = nil
	output, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("write vhost config: %s: %s", err, string(output))
	}

	// Create symlink in sites-enabled
	linkPath := filepath.Join(sitesEnabled, domain+".conf")
	exec.Command("sudo", "rm", "-f", linkPath).Run()
	cmd = exec.Command("sudo", "ln", "-s", confPath, linkPath)
	if output, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("create symlink: %s", string(output))
	}

	return nil
}

// RemoveVHost removes a vhost config and symlink
func RemoveVHost(sitesAvailable, sitesEnabled, domain string) error {
	exec.Command("sudo", "rm", "-f", filepath.Join(sitesEnabled, domain+".conf")).Run()
	exec.Command("sudo", "rm", "-f", filepath.Join(sitesAvailable, domain+".conf")).Run()
	return nil
}

// TestConfig runs nginx -t to validate configuration
func TestConfig() error {
	cmd := exec.Command("sudo", "nginx", "-t")
	output, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("nginx config test failed: %s", string(output))
	}
	return nil
}

// Reload reloads nginx configuration
func Reload() error {
	cmd := exec.Command("sudo", "systemctl", "reload", "nginx")
	output, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("nginx reload failed: %s", string(output))
	}
	return nil
}

// TestAndReload validates then reloads nginx
func TestAndReload() error {
	if err := TestConfig(); err != nil {
		return err
	}
	return Reload()
}
